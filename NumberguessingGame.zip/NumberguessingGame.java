import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NumberguessingGame extends JFrame implements ActionListener {
    private JLabel questionLabel;
    private JTextField answerField;
    private JButton submitButton;
    private JLabel resultLabel;
    private JLabel resultLabe2;
    private JLabel resultLabe3;
    private int correctAnswers;
    private int wrongAnswers;

    private String[] questions = {
            "Enter a number between 1 to 100:",
            "Enter another number between 1 to 100:",
            "Enter one more number between 1 to 100:",
            "Enter yet another number between 1 to 100:",
            "Enter the last number between 1 to 100:"
    };

    private NumberguessingGame() {
        setTitle("Swing Quiz App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(350, 600);
        setLayout(null);

        questionLabel = new JLabel();
        questionLabel.setBounds(50, 30, 300, 30);
        add(questionLabel);

        answerField = new JTextField();
        answerField.setBounds(50, 70, 200, 30);
        add(answerField);

        submitButton = new JButton("Submit");
        submitButton.setBounds(50, 110, 100, 30);
        submitButton.addActionListener(this);
        add(submitButton);

        resultLabel = new JLabel();
        resultLabel.setBounds(50, 150, 300, 30);
        add(resultLabel);

        resultLabe2 = new JLabel();
        resultLabe2.setBounds(50, 200, 300, 30);
        add(resultLabe2);

        resultLabe3 = new JLabel();
        resultLabe3.setBounds(50, 250, 300, 30);
        add(resultLabe3);

        correctAnswers = 0;
        wrongAnswers = 0;

        askQuestion(0);
    }

    private void askQuestion(int index) {
        if (index < questions.length) {
            questionLabel.setText(questions[index]);
            answerField.setText("");
            resultLabel.setText("");
        } else {
            double percentage = (double) correctAnswers / questions.length * 100;
            resultLabel.setText("Quiz completed.\nCorrect answers: " + correctAnswers);
            resultLabe2.setText("\nWrong answers: " + wrongAnswers);
            resultLabe3.setText("\nPercentage: " + percentage + "%");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int inputNumber = Integer.parseInt(answerField.getText());
        if (inputNumber >= 1 && inputNumber <= 100) {
            correctAnswers++;
        } else {
            wrongAnswers++;
        }

        askQuestion(correctAnswers + wrongAnswers);
    }

    public static void main(String[] args) {
        NumberguessingGame app = new NumberguessingGame();
        app.setVisible(true);
}
}